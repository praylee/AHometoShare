/* File: SimpleDemo.java
 * Author: Stanley Pieda
 * Date: 2015
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */
import businesslayer.AuthorsBusinessLogic;
import businesslayer.ValidationException;
import transferobjects.Author;

import java.util.List;
public class SimpleDemo {

	public void demo(){
		try{
			AuthorsBusinessLogic logic = new AuthorsBusinessLogic();
			List<Author> list = null;
			Author author = null;
			
			System.out.println("Printing Authors");
			list = logic.getAllAuthors();
			printAuthors(list);
			
			System.out.println("Printing One Author");
			author = logic.getAuthor( new Integer(1) );
			printAuthor(author);
			System.out.println();
			
			System.out.println("Inserting One Author");
			author = new Author();
			author.setFirstName("FirstTestAdd");
			author.setLastName("LastTestAdd");
			logic.addAuthor(author);
			list = logic.getAllAuthors();
			printAuthors(list);
			
			System.out.println("Updateing last author");
			Integer updatePrimaryKey = list.get(list.size() - 1).getAuthorID();
			author = new Author();
			author.setAuthorID(updatePrimaryKey);
			author.setFirstName("FirstTestUpdate");
			author.setLastName("LastTestUpdate");
			logic.updateAuthor(author);
			list = logic.getAllAuthors();
			printAuthors(list);
			
			System.out.println("Deleteing last author");
			author = list.get(list.size() - 1);
			logic.deleteAuthor(author);
			list = logic.getAllAuthors();
			printAuthors(list);	
		}
		catch(ValidationException e){
			System.err.println(e.getMessage());
		}

	}
	
	private static void printAuthor(Author author){
	    	String output = String.format("%s, %s, %s",
	    			author.getAuthorID().toString(),
	    			author.getFirstName(),
	    			author.getLastName());
	    	System.out.println(output);
	}
	
	private static void printAuthors(List<Author> authors){
	    for(Author author : authors){
	    	printAuthor(author);
	    }
	    System.out.println();
	}
	

}
